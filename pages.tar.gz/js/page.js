function usingAjax(url) {
		$.ajax({
				url:url,
				statusCode: {
						404: function(){alert('Page not found');}
				},
				beforeSend: function(xhr) {
						xhr.overrideMimeType("text/plain;charset=x-user-defined");
						if( $('#SearchBox input[name="q"]').attr("value") == ""){
								$('<div></div>').html('<p style="font-size:12px;">' + 
			 'To browse or use our site properly,' + 
			 'we suggest using the latest Google chrome or firefox to browse our site.'+
		     '</p>').dialog({
										title: 'Information',	
			 							autoOpen:false,
			 							height: 180,
			 							resizable: false,
			 							modal : true,
			 							buttons: { Ok: function() { $(this).dialog("close"); } }
								}).dialog("open");
						}else{
								$("#status_mesg").html('<div id="loader">'+
																			 '<img src="css/images/spinner.gif" alt="loading..." />  Searching...</div>');
						}
				}
		})
		.done(function(data){
				$("#status_mesg").html('<div id="loader">Completed</div>');
		})
		.fail(function(){alert("Error");})
		.always(function(){alert("Complete");});
	
}

$(document).ready(function(){
		var url = 'http://192.168.0.168:80/...';

		$('#SearchBox').submit(function(event){
				if( $('#SearchBox input[name="q"]').attr("value") == ""){
						alert('Keywords is empty');		
				}else{
						usingAjax(url);
				}
				return event.preventDefault();
		});
		
});